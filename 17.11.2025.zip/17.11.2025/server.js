// server.js
const express = require('express');
const { faker } = require('@faker-js/faker');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json()); // parsowanie JSON w body

// In-memory storage
let users = [];
let nextId = 1;

// Helper: generate one fake user
function generateFakeUser(id) {
  return {
    id,
    name: faker.person.firstName(),
    surname: faker.person.lastName(),
    age: faker.number.int({ min: 18, max: 90 }),
    phone: faker.phone.number(),
    profession: faker.person.jobTitle(),
    address: faker.location.streetAddress() + ", " + faker.location.city()
  };
}

// Generate 200 fake users on startup
for (let i = 0; i < 200; i++) {
  users.push(generateFakeUser(nextId++));
}

// ROUTES

// GET /users  -> return all users (optionally support ?limit=&offset=)
app.get('/users', (req, res) => {
  // Opcjonalne paginowanie (limit, offset)
  const limit = parseInt(req.query.limit) || users.length;
  const offset = parseInt(req.query.offset) || 0;

  const result = users.slice(offset, offset + limit);
  res.json({
    count: result.length,
    total: users.length,
    data: result
  });
});

// GET /users/:id -> return user by id
app.get('/users/:id', (req, res) => {
  const id = parseInt(req.params.id);
  if (Number.isNaN(id)) return res.status(400).json({ error: 'Invalid id' });

  const user = users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  res.json(user);
});

// POST /users -> create new user
// Expected body JSON: { name, surname, age, phone, profession, address }
app.post('/users', (req, res) => {
  const { name, surname, age, phone, profession, address } = req.body;

  // Prosta walidacja
  if (!name || !surname || !profession || !phone || !address) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const ageNum = Number(age);
  if (Number.isNaN(ageNum) || ageNum < 0 || ageNum > 150) {
    return res.status(400).json({ error: 'Invalid age' });
  }

  const newUser = {
    id: nextId++,
    name,
    surname,
    age: ageNum,
    phone,
    profession,
    address
  };

  users.push(newUser);

  res.status(201).json(newUser);
});

// Healthcheck root
app.get('/', (req, res) => {
  res.send('Fake Users API is running. Try GET /users');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
