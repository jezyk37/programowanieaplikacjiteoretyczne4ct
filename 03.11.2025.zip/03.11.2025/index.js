const express = require('express');
const serwerLogs = require('./serwerLogs');
//wywołanie framework
const app = express();
const port = 8080;

//obsługa żądania po GET- wyswietlanie strony glownej
//sciezka do plikow strony

// const main = 'index.html'
// const css = 'main.css'
// const js = 'main.js'

app.get('/',(req,res)=>{
    // res.sendFile(main,{root:__dirname + '\\strona'});
    // serwerLogs.show(main,req)

    //pobieram przesłane zmienne
    const q = req.query.q;
    const sclient = req.query.sclient;

    //drugi sposob pobierania zmienych przez destrukturyzacje
    res.send(`
        ${q},
        ${sclient}
        `)
});

// app.get('/main.css',(req,res)=>{
//     res.sendFile(css,{root:__dirname + '\\strona'});
//     serwerLogs.show(css,req)
// });
// app.get('/main.js',(req,res)=>{
//     res.sendFile(js,{root:__dirname + '\\strona'});
//     serwerLogs.show(js,req)
// });

app.listen(port,()=>{console.log("Serwer poprawnie uruchomiony")})