module.exports={
    show(file,request){
        console.log(`
            Wysłano: ${file}
            protocol: ${request.protocol}
            secure: ${request.secure}
            url: ${request.url}
            originalURL: ${request.originalURL}
            path: ${request.path}
            ip: ${request.ip}
            `)
    }
}